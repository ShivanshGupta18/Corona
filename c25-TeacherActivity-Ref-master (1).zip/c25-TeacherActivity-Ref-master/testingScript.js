var firebaseConfig = {
    apiKey: "AIzaSyA9F6zriCDRHGeu-LwJ83CplHUKkQVCr0M",
    authDomain: "corona-9e261.firebaseapp.com",
    databaseURL: "https://corona-9e261.firebaseio.com",
    projectId: "corona-9e261",
    storageBucket: "corona-9e261.appspot.com",
    messagingSenderId: "694830677499",
    appId: "1:694830677499:web:b9382e363351f4b3701f5e"
  };

  firebase.initializeApp(firebaseConfig);
  
  